// ==UserScript==
// @name         XTRF – Dashboard Theme (parent + iframe) v1.4.1
// @namespace    http://tampermonkey.net/
// @version      1.4.1
// @description  Theme dashboard + smart views inside iframes (genericBrowseIFrame). Live preview, safe with status-color scripts.
// @match        https://translations.myelan.net/xtrf/faces/dashboard2/dashboard.seam*
// @match        https://translations.myelan.net/xtrf/faces/dashboard2/genericBrowseIFrame.seam*
// @grant        none
// @run-at       document-end
// @noframes
// ==/UserScript==

(function () {
  "use strict";

  const STORAGE_KEY = "xtrf_dashboard_theme_v2";

  const DEFAULT_THEME = {
    bgColor: "#e9eef3",
    bgAlpha: 1.0,
    radius: 22,
    shadowEnabled: true,
    darkMode: false
  };

  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const safeParse = (s) => { try { return JSON.parse(s); } catch { return null; } };
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim().toLowerCase();

  function loadTheme() {
    const saved = safeParse(localStorage.getItem(STORAGE_KEY));
    const t = { ...DEFAULT_THEME };
    if (saved && typeof saved === "object") {
      if (typeof saved.bgColor === "string") t.bgColor = saved.bgColor;
      if (typeof saved.bgAlpha === "number") t.bgAlpha = clamp(saved.bgAlpha, 0.15, 1);
      if (typeof saved.radius === "number") t.radius = clamp(saved.radius, 0, 40);
      if (typeof saved.shadowEnabled === "boolean") t.shadowEnabled = saved.shadowEnabled;
      if (typeof saved.darkMode === "boolean") t.darkMode = saved.darkMode;
    }
    return t;
  }

  function saveTheme(t) { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(t)); } catch {} }

  // --- color helpers
  function hexToRgb(hex) {
    const h = (hex || "#000").replace("#", "").trim();
    const full = h.length === 3 ? h.split("").map(c => c + c).join("") : h.padEnd(6, "0").slice(0, 6);
    const n = parseInt(full, 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }
  function rgbaFromHex(hex, alpha) {
    const { r, g, b } = hexToRgb(hex);
    const a = clamp(typeof alpha === "number" ? alpha : 1, 0, 1);
    return `rgba(${r}, ${g}, ${b}, ${a})`;
  }
  function darkenHex(hex, pct) {
    const p = clamp(pct, 0, 100) / 100;
    const { r, g, b } = hexToRgb(hex);
    const nr = Math.round(r * (1 - p));
    const ng = Math.round(g * (1 - p));
    const nb = Math.round(b * (1 - p));
    const toHex = (x) => x.toString(16).padStart(2, "0");
    return `#${toHex(nr)}${toHex(ng)}${toHex(nb)}`;
  }

  function injectCSS(id, css) {
    let el = document.getElementById(id);
    if (!el) {
      el = document.createElement("style");
      el.id = id;
      document.head.appendChild(el);
    }
    el.textContent = css;
  }

  function applyTheme(theme, context /* 'parent' | 'iframe' */) {
    document.documentElement.classList.toggle("xtrf-darkmode", !!theme.darkMode);

    const canvasBgHex = theme.darkMode ? darkenHex(theme.bgColor, 72) : theme.bgColor;
    const canvasBg = rgbaFromHex(canvasBgHex, theme.darkMode ? 1 : theme.bgAlpha);

    const radiusPx = `${theme.radius}px`;
    const shadow = theme.shadowEnabled ? "0 14px 36px rgba(0,0,0,0.22)" : "none";

    const dmTabs    = "rgba(56, 56, 56, 0.98)";
    const dmTitle   = "rgba(70, 70, 70, 0.98)";
    const dmHeader  = "rgba(85, 85, 85, 0.96)";
    const dmCard    = "rgba(34, 34, 34, 0.92)";
    const dmInner   = "rgba(26, 26, 26, 0.92)";
    const dmInner2  = "rgba(20, 20, 20, 0.92)";

    const dmText    = "rgba(255,255,255,0.92)";
    const dmBorder  = "rgba(255,255,255,0.14)";
    const dmGrid    = "rgba(255,255,255,0.10)";
    const dmHover   = "rgba(255,255,255,0.06)";

    document.documentElement.style.setProperty("--xtrf-bg", canvasBg);
    document.documentElement.style.setProperty("--xtrf-radius", radiusPx);
    document.documentElement.style.setProperty("--xtrf-shadow", shadow);

    document.documentElement.style.setProperty("--xtrf-tabs-bg", dmTabs);
    document.documentElement.style.setProperty("--xtrf-titlebar-bg", dmTitle);

    document.documentElement.style.setProperty("--xtrf-card-bg", theme.darkMode ? dmCard : "rgba(255,255,255,0.90)");
    document.documentElement.style.setProperty("--xtrf-card-inner", theme.darkMode ? dmInner : "rgba(255,255,255,0.90)");
    document.documentElement.style.setProperty("--xtrf-card-inner2", theme.darkMode ? dmInner2 : "rgba(0,0,0,0.02)");

    document.documentElement.style.setProperty("--xtrf-card-header-bg", theme.darkMode ? dmHeader : "rgba(0,0,0,0.02)");
    document.documentElement.style.setProperty("--xtrf-text", theme.darkMode ? dmText : "inherit");

    document.documentElement.style.setProperty("--xtrf-border", theme.darkMode ? dmBorder : "rgba(0,0,0,0.10)");
    document.documentElement.style.setProperty("--xtrf-grid", theme.darkMode ? dmGrid : "rgba(0,0,0,0.10)");
    document.documentElement.style.setProperty("--xtrf-hover", theme.darkMode ? dmHover : "rgba(0,0,0,0.03)");

    // Parent dashboard styles (tabs, title bar, cards)
    const parentCSS = `
      .x-grid { background: var(--xtrf-bg) !important; }
      .x-grid > * { background-color: transparent !important; }

      .xtrf-darkmode .x-tabs,
      .xtrf-darkmode .x-tabs__bar,
      .xtrf-darkmode .x-tab-bar,
      .xtrf-darkmode .x-tabs__header,
      .xtrf-darkmode .x-tabs__container,
      .xtrf-darkmode .x-tabs__wrapper {
        background: var(--xtrf-tabs-bg) !important;
        border-bottom: 1px solid var(--xtrf-border) !important;
      }
      .xtrf-darkmode .x-tabs * { color: var(--xtrf-text) !important; }

      .xtrf-darkmode .x-title-bar {
        background: var(--xtrf-titlebar-bg) !important;
        border-bottom: 1px solid var(--xtrf-border) !important;
      }
      .xtrf-darkmode .x-title-bar * { color: var(--xtrf-text) !important; }

      .xtrf-darkmode .x-title-bar .x-btn.--large {
        background: rgba(0,0,0,0.25) !important;
        color: var(--xtrf-text) !important;
        border: 1px solid var(--xtrf-border) !important;
        box-shadow: none !important;
      }
      .xtrf-darkmode .x-title-bar .x-btn.--large:hover { background: rgba(0,0,0,0.35) !important; }

      .x-card, .xlt-card, .xdb-dashboard__widget, .card, .panel {
        border-radius: var(--xtrf-radius) !important;
        box-shadow: var(--xtrf-shadow) !important;
        overflow: hidden !important;
        border: 1px solid var(--xtrf-border) !important;
        background: var(--xtrf-card-bg) !important;
      }

      .x-card__header, .xlt-card__header, .card-header {
        background: var(--xtrf-card-header-bg) !important;
        border-bottom: 1px solid var(--xtrf-border) !important;
        font-weight: 800 !important;
      }
      .xtrf-darkmode .x-card__header *, .xtrf-darkmode .xlt-card__header * {
        color: var(--xtrf-text) !important;
        font-weight: 800 !important;
      }

      #xtrf-palette-btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        min-width: 44px !important;
      }
    `;

    // Iframe smart view styles (THIS is what you were missing)
    const iframeCSS = `
      html, body { background: var(--xtrf-card-inner) !important; }

      .xtrf-darkmode .x-page__section.x-section,
      .xtrf-darkmode .xb-filters-list__wrapper,
      .xtrf-darkmode .xb-filters-list.x-form,
      .xtrf-darkmode .x-page.dummy-viewport {
        background: var(--xtrf-card-inner) !important;
        color: var(--xtrf-text) !important;
      }

      .xtrf-darkmode table.x-table,
      .xtrf-darkmode .x-table {
        background: var(--xtrf-card-inner) !important;
        color: var(--xtrf-text) !important;
      }

      .xtrf-darkmode th.x-table.--head,
      .xtrf-darkmode .x-table.--head {
        background: var(--xtrf-card-inner2) !important;
        color: var(--xtrf-text) !important;
        border-color: var(--xtrf-grid) !important;
      }

      /* Your DOM: td.x-table__body.--text */
      .xtrf-darkmode td.x-table__body,
      .xtrf-darkmode td.x-table__body.--text {
        background: var(--xtrf-card-inner) !important;
        color: var(--xtrf-text) !important;
        border-color: var(--xtrf-grid) !important;
      }

      .xtrf-darkmode .x-table__backdrop {
        background: var(--xtrf-card-inner2) !important;
      }

      .xtrf-darkmode tr.x-table__row:hover,
      .xtrf-darkmode .x-table__row:hover {
        background: var(--xtrf-hover) !important;
      }

      .xtrf-darkmode .x-clamp__container,
      .xtrf-darkmode .x-clamp__element {
        background: transparent !important;
        color: var(--xtrf-text) !important;
      }
    `;

    injectCSS(
      "xtrf-dashboard-theme-css",
      (context === "iframe") ? iframeCSS : parentCSS
    );
  }

  // -------- Palette UI (parent only)
  let popover = null;

  function closePopover() {
    if (!popover) return;
    popover.remove();
    popover = null;
    document.removeEventListener("pointerdown", onOutsidePointerDown, true);
    document.removeEventListener("keydown", onKeyDown, true);
  }

  function onOutsidePointerDown(ev) {
    const btn = document.getElementById("xtrf-palette-btn");
    if (!popover) return;
    if (popover.contains(ev.target)) return;
    if (btn && (btn === ev.target || btn.contains(ev.target))) return;
    closePopover();
  }

  function onKeyDown(ev) {
    if (ev.key === "Escape") closePopover();
  }

  function openPopover(anchorBtn) {
    const theme = loadTheme();
    const r = anchorBtn.getBoundingClientRect();
    const top = Math.round(r.bottom + 10);
    const right = Math.round(Math.max(12, window.innerWidth - r.right));

    popover = document.createElement("div");
    Object.assign(popover.style, {
      position: "fixed",
      top: `${top}px`,
      right: `${right}px`,
      width: "320px",
      padding: "14px",
      borderRadius: "18px",
      background: "rgba(255,255,255,0.95)",
      boxShadow: "0 20px 50px rgba(0,0,0,0.18)",
      zIndex: 999999,
      fontFamily: "system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif",
      fontSize: "13px",
      color: "#1f2328",
      border: "1px solid rgba(0,0,0,0.10)"
    });

    popover.innerHTML = `
      <div style="font-weight:750;margin-bottom:10px;">Dashboard theme</div>

      <section style="padding:10px;border-radius:14px;border:1px solid rgba(0,0,0,0.08); margin-bottom:12px;">
        <div style="font-weight:650;margin-bottom:8px;">Background</div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
          <label style="opacity:.85;">Color</label>
          <input type="color" id="bgColor" value="${theme.bgColor}" style="width:56px;height:34px;border:none;background:transparent;cursor:pointer;">
        </div>
        <div style="margin-top:10px;display:flex;align-items:center;justify-content:space-between;gap:10px;">
          <label style="opacity:.85;">Opacity</label>
          <input type="range" id="bgAlpha" min="0.15" max="1" step="0.01" value="${theme.bgAlpha}" style="width:210px;cursor:pointer;">
        </div>
      </section>

      <section style="padding:10px;border-radius:14px;border:1px solid rgba(0,0,0,0.08); margin-bottom:12px;">
        <div style="font-weight:650;margin-bottom:8px;">Smart Views</div>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;">
          <label style="opacity:.85;">Card radius</label>
          <input type="range" id="radius" min="0" max="40" step="1" value="${theme.radius}" style="width:210px;cursor:pointer;">
        </div>
        <label style="margin-top:10px;display:flex;align-items:center;gap:8px;cursor:pointer;">
          <input type="checkbox" id="shadow" ${theme.shadowEnabled ? "checked" : ""}>
          <span>Enable shadow</span>
        </label>
      </section>

      <section style="padding:10px;border-radius:14px;border:1px solid rgba(0,0,0,0.08); margin-bottom:12px;">
        <div style="font-weight:650;margin-bottom:8px;">Mode</div>
        <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
          <input type="checkbox" id="dark" ${theme.darkMode ? "checked" : ""}>
          <span>Dark mode</span>
        </label>
      </section>

      <div style="display:flex;justify-content:flex-end;gap:8px;">
        <button id="resetBtn" style="padding:7px 11px;border-radius:10px;border:1px solid rgba(0,0,0,0.12);background:rgba(0,0,0,0.05);cursor:pointer;">Reset</button>
        <button id="saveBtn" style="padding:7px 11px;border-radius:10px;border:1px solid rgba(0,0,0,0.12);background:#0b6cff;color:#fff;cursor:pointer;box-shadow:0 10px 22px rgba(11,108,255,0.22);">Save</button>
      </div>
    `;

    popover.addEventListener("pointerdown", (e) => e.stopPropagation());
    document.body.appendChild(popover);

    const $ = (sel) => popover.querySelector(sel);
    const bgColor = $("#bgColor");
    const bgAlpha = $("#bgAlpha");
    const radius  = $("#radius");
    const shadow  = $("#shadow");
    const dark    = $("#dark");

    function themeFromUI() {
      return {
        bgColor: bgColor.value,
        bgAlpha: parseFloat(bgAlpha.value),
        radius: parseInt(radius.value, 10),
        shadowEnabled: !!shadow.checked,
        darkMode: !!dark.checked
      };
    }

    function preview() {
      const t = themeFromUI();
      saveTheme(t);                // so iframes pick it up quickly
      applyTheme(t, "parent");     // update parent
      // iframes read localStorage; they will update on storage/poll below
    }

    [bgColor, bgAlpha, radius, shadow, dark].forEach(el => {
      el.addEventListener("input", preview);
      el.addEventListener("change", preview);
    });

    $("#saveBtn").addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      const t = themeFromUI();
      saveTheme(t);
      applyTheme(t, "parent");
      closePopover();
    });

    $("#resetBtn").addEventListener("click", (e) => {
      e.preventDefault(); e.stopPropagation();
      saveTheme({ ...DEFAULT_THEME });
      applyTheme({ ...DEFAULT_THEME }, "parent");
      closePopover();
    });

    preview();

    document.addEventListener("pointerdown", onOutsidePointerDown, true);
    document.addEventListener("keydown", onKeyDown, true);
  }

  function findEditDashboardButton() {
    const buttons = Array.from(document.querySelectorAll("button.x-btn.--large"));
    for (const b of buttons) if (norm(b.textContent) === "edit dashboard") return b;
    for (const b of Array.from(document.querySelectorAll("button"))) if (norm(b.textContent) === "edit dashboard") return b;
    return null;
  }

  function ensurePaletteButton() {
    if (document.getElementById("xtrf-palette-btn")) return;
    const editBtn = findEditDashboardButton();
    if (!editBtn) return;

    const paletteBtn = editBtn.cloneNode(true);
    paletteBtn.id = "xtrf-palette-btn";
    paletteBtn.title = "Dashboard theme";
    paletteBtn.textContent = "🎨";

    paletteBtn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      popover ? closePopover() : openPopover(paletteBtn);
    });

    editBtn.insertAdjacentElement("afterend", paletteBtn);
  }

  // --------- Init for parent vs iframe
  const isIframeView = location.href.includes("genericBrowseIFrame.seam");
  const context = isIframeView ? "iframe" : "parent";

  function init() {
    const t = loadTheme();
    applyTheme(t, context);
    if (!isIframeView) ensurePaletteButton();
  }

  init();

  // Parent: observe for rerenders
  try {
    new MutationObserver(() => init()).observe(document.body, { childList: true, subtree: true });
  } catch {}

  // Iframe: poll theme changes (storage event often doesn't fire inside same tab reliably)
  if (isIframeView) {
    let last = localStorage.getItem(STORAGE_KEY) || "";
    setInterval(() => {
      const cur = localStorage.getItem(STORAGE_KEY) || "";
      if (cur !== last) {
        last = cur;
        init();
      }
    }, 400);
  }
})();
